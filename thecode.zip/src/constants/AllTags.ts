const allInterests = ["Sports", "Movies", "Business", "Education", "Politics", "International", "Technology", "Food", "Music", "Health"];

export default allInterests;