type ButtonProps = {
    onClick: VoidFunction,
    text: string
};

export default ButtonProps;