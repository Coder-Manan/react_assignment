type LoginPageState = {};

export type {LoginPageState};