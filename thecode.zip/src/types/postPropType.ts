type PostProps = {
    id: string
}

export default PostProps;