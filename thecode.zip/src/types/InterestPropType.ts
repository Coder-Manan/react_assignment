type InterestProps = {
    interest: string
};

export default InterestProps;