import { type } from "@testing-library/user-event/dist/type"

type LoginPageProps ={}

export type {LoginPageProps};