type MainNavProps = {
    userName: string,
    pictureURL: string
}

export default MainNavProps;