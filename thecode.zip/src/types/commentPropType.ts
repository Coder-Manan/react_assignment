type CommentProps = {
    comment : string,
    commentator: string
}

export default CommentProps;